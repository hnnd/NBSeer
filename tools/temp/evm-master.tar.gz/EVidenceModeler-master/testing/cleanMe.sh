#!/bin/bash

set -ex

rm -rf ./__smalltest* ./smalltest.*


