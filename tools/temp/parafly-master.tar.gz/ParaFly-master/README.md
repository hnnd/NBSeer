# ParaFly
ParaFly - parallel cmd processing utility
